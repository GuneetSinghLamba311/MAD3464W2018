/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ReservationSystem;

/**
 *
 * @author macstudent
 */
public class TenSeatsPlane {
    int smokingseats;
    int noSmokingseats;
    
  int smokingArray[] = new int[5];
  int nonSmokingArray[] = new int[5];
    
    TenSeatsPlane(int smoking,int nonsmoking) {
        this.smokingseats = smoking;     
    this.noSmokingseats = nonsmoking;
    System.out.println("smokingseats: " + this.smokingseats);
    System.out.println("noSmokingseats: "  + this.noSmokingseats);
        
     }
    
    void smokingSeats() {
        for(int i=0; i<smokingArray.length;i++) {
            smokingArray[i] = 1;
        }
    }
        void nonsmokingSeats() {
        for(int i=0; i<nonSmokingArray.length;i++) {
            nonSmokingArray[i] = 1;
        }
    
        
        
        
        
    }
    
  }
