/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ReservationSystem;

/**
 *
 * @author macstudent
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */

import java.util.*;
public class BookTicket {
    
    
    public static void main(String[] args) {
        
        System.out.println("For regular plane press 1|| for first class 10 seats plane press 2");
        Scanner whichPlane = new Scanner(System.in);
        
        if (whichPlane.nextInt() == 1)
        {
         BigPlane obj1 = new BigPlane(10,20);
        obj1.assignSeats();
        obj1.assignCapacity();
        obj1.display();
        
        }
        else {
            System.out.println("This is a 10 seats plane");
            System.out.println("for smoking zone press 1|| for non-smokingzone press 2");
            Scanner zone = new Scanner(System.in);
        zone.nextInt();
           if (zone.nextInt() == 1)
        {
        TenSeatsPlane obj1 = new TenSeatsPlane (5,5);
        obj1.smokingSeats();
        }
        else if (zone.nextInt() == 1) {
            TenSeatsPlane obj2 = new TenSeatsPlane (5,5);
                obj2.nonsmokingSeats();
           }
        
   }
            }
    }
    
    

