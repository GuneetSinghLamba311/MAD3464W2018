/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ReservationSystem;

/**
 *
 * @author macstudent
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class BigPlane {
   
    int seats;
    int capaty;
    int seatsBooked[] = new int[10];
    int capacity[] = new int [20];
    
    
    BigPlane(int booked,int capacity) {
        
   this.seats = booked;     
   this.capaty = capacity;
    System.out.println("Seats Booked: " + this.seats);
    System.out.println("Seats Capacity: "  + this.capaty);
    }
    
    
    
    void assignSeats() {
        
        for(int i=0; i<seatsBooked.length;i++) {
            seatsBooked[i] = 1;
        }
    }
      void assignCapacity() {
        
        for(int i=0; i<capacity.length;i++) {
            capacity[i] = 0;
        }
    }
void display()
{
     for(int i=0; i<seatsBooked.length;i++) {
     System.out.println("Seats Booked " + seatsBooked[i]);   
     }
      for(int i=0; i<capacity.length;i++) {
     System.out.println("Capacity " + capacity[i]);   
     }
     
    
}








    
}
