/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;



/**
 *
 * @author macstudent
 */
public class Inheritance {
    
     public static void main(String[] args) {
        
        Person obj1 = new Person();
        obj1.display();
        Person obj2 = new Person("Guneet","Singh",23);
         obj2.display();
         
         
         
       //  Employee e1 = new Employee("Guneet","Singh",23,1450.87);
        // e1.display();
         
         Employee e2 = new Employee();
         e2.firstName = "GH";
         e2.lastName = "SH";
         e2.age = 10;
         e2.salary = 1000;
         
         e2.display();
         e2.display();
         
        // Method Overriding.
        
         Employee e3 = new Employee();
         e3.read();
         e3.display();
         
         }
   
 
}
