/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
package inheritance;

import java.util.*;
 public class Person {

String firstName;
String lastName;
int age;


Person() { // Default Constructor
    
    
    
    
    this.firstName = "Unknown";
    this.lastName = "Unknown";
    this.age = 1;
    }


Person(String fname, String lname, int age)  // Parametrized Constructor.

{
    
    this.firstName = fname;
    this.lastName = lname;
    this.age = age;
    }

// COPY CONSTRUCTOR.
Person(Person object) {
    
   this.firstName = object.firstName;
    this.lastName = object.lastName;
    this.age = object.age;
    
    
    
}



    void read() {
    
    Scanner input = new Scanner(System.in);
    System.out.println("Enter first name: ");
    this.firstName = input.nextLine();
    System.out.println("Enter last name: ");
    this.lastName  = input.nextLine();
    System.out.println("Enter age ");
    this.age = input.nextInt();
    }


    void display() {
    System.out.println(" first name: " + this.firstName);
    System.out.println(" last name: " + this.lastName);
    System.out.println(" age: " + this.age);
    }
}
