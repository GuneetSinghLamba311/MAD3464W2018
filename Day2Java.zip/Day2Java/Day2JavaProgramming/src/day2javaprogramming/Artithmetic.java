/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2javaprogramming;

/**
 *
 * @author macstudent
 */
public class Artithmetic {
    
    static int n1;
   final static int n2 = 10;
    
//  int Addition(int num1, int num2) { // Parametrized function with return type of integer.
//        
//        return num1 + num2;
//        }
//  
//  
//  int Addition(int num1, int num2, int num3) {
//      return num1 + num2 + num3;
//  
//  }
    
 static int Addition(int... num) { // accesing multiple arguments at one time.Used for if you dont know how many arguments are there to pass.
     
     int i=0,sum=0 ;
     
     for(i=0;i<num.length;i++){
         sum+= num[i];
     }
     return sum;
     }   
    
    

  static float Addition(float num1, float num2) { // Same function with different return type of float.
      
       
      multiplication(20,20);
      return num1 + num2;
      
  }
  // method overloading.
  
  
  static int multiplication(int... num) {
      int i,mul;
for (i=0,mul=1;i<num.length;i++) {
    mul *= num[i];
    
}
System.out.println("MulValueWhenCalledIN Function:" + mul);
return mul;
      }
  
  
    
}
