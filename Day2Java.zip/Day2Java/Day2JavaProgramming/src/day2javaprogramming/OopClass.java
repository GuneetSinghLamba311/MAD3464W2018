/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2javaprogramming;
import java.util.Scanner;
/**
 *
 * @author macstudent
 */
public class OopClass {
    
    public static void main(String[] args) {
        
        Bank myBank = new Bank(); // Creating an object.
        
        
       System.out.println("Bank ID:" + myBank.bankID);
       System.out.println("Bank ID:" + myBank.bankName);
      
       Bank yourBank = new Bank(); // Creating another new object.
       yourBank.bankID = 123456;
       yourBank.bankName = "ScotiaBank";
       System.out.println("Bank ID:" + yourBank.bankName);
       myBank.getBankName();
       yourBank.setBankName("RBC"); // Assigning new value to the function.
       
       Scanner getInput = new Scanner(System.in);
        String name;
        System.out.println("Enter bank Name: ");
        name = getInput.nextLine();
        
        yourBank.setBankName(name);
        yourBank.getBankName();
        
        
        Artithmetic add = new Artithmetic();
        System.out.println("Sum value: " + add.Addition(100, 200));
        System.out.println("Sum value: " + add.Addition(10.23f, 20.12f));
        System.out.println("Sum value: " + add.Addition(100, 200,300));
        System.out.println("mul value: " + add.multiplication(5,2));
        Artithmetic.multiplication(10,20);
        Artithmetic.n1 = 20;
        //Artithmetic.n2 = 20; 
        
        System.out.println(Artithmetic.n1 + " " + Artithmetic.n2);
        
         }
    
         
    

}
