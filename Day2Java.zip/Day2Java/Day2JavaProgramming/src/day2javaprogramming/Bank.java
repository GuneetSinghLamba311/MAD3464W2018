/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2javaprogramming;


/**
 *
 * @author macstudent
 */
public class Bank {
    int bankID = 10102;
    String bankName = "TD";
    
    
    void getBankName() {
        System.out.println("BankName: " + this.bankName);
        
        
    }
    
    void setBankName(String name) 
    {
        bankName = name;
        System.out.println("New Bank Name:" + bankName);
    }
    
}



