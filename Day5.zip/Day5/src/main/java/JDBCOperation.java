/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 727012
 */ 
import java.sql.*;
public class JDBCOperation {
    static Connection conn;
    static PreparedStatement stmt;
    static ResultSet rs;
    static String User = "root";
    static String PASS = "";
 
    
    public static void main(String[] args) {
    connectDB();
    selectDB();
    insertDB();
    updateDB();
    deleteDB();
    selectDB();
    closeDB();
    
   }
   
 static void connectDB() {
     
     try {
     Class.forName("com.mysql.jdbc.Driver");
     conn = DriverManager.getConnection("jdbc:mysql://localhost/madwinter18", User, PASS);
         
     } 
     catch(Exception e) {
         
         e.printStackTrace();
     }
     
         
     }
     
     static void insertDB() {
         
         try {
         stmt = conn.prepareStatement("insert into Person values(?,?,?,?)");
         
         stmt.setInt(1,102);
         stmt.setString(2,"John");
         stmt.setString(3,"Cena");
         stmt.setInt(4,35);
         
         
         int i = stmt.executeUpdate();
         
         System.out.println(i+ "records inserted");
         }
         catch(SQLException se)
         {
             se.printStackTrace();
         }
}
     
     static void selectDB() {
         
         try {
             stmt = conn.prepareStatement("SELECT * FROM Person");
            rs = stmt.executeQuery();
             
             while(rs.next()){
                 System.out.println("id:" + rs.getInt("id") + "FirstName:" + rs.getString("FirstName") + "LastName:"
                 + rs.getString("LastName") + "Age:" + rs.getInt("Age"));
         }
         }
         catch(SQLException e)
         {
             e.printStackTrace();
         }
     }
     static void deleteDB() {
          
         try {
         stmt = conn.prepareStatement("Delete FROM Person  where id = ?");
         
         stmt.setInt(1,101);
        int i = stmt.executeUpdate();
         
         System.out.println(i+ "records Deleted");
         }
         catch(SQLException se)
         {
             se.printStackTrace();
         }
    }
     
     
      static void updateDB() 
      {
            try {
         stmt = conn.prepareStatement("Update Person SET FirstName = ?, LastName = ?, Age = ? WHERE Id = ?");
         
        stmt.setInt(1,102);
         stmt.setString(2,"Johny");
         stmt.setString(3,"walker");
         stmt.setInt(4,35);
        int i = stmt.executeUpdate();
         
         System.out.println(i+ "records inserted");
         }
         catch(SQLException se)
         {
             se.printStackTrace();
         }
    
      }
      static void closeDB(){
            try{
                if (conn!= null){
                    conn.close();
                }
            }
            catch(SQLException e){
                e.printStackTrace();;
            }
     }
}
