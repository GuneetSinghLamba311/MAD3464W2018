/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guneetsingh_c0727012_mad3464_midtermtest;

/**
 *
 * @author macstudent
 */
import java.util.*;
public class GuneetSingh_C0727012_MAD3464_MidtermTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        EncryptionOne one = new EncryptionOne();
        one.Operation();
        EncryptionTwo two = new EncryptionTwo();
        two.operation();
        EncryptionThree three = new EncryptionThree();
        three.operatrion();
        System.out.println("For Bowler press 1 and for batsman press 2");
        Scanner get = new Scanner(System.in);
        if(get.nextInt() == 1) {
        Bowler bowl = new Bowler();
        bowl.readData();
        bowl.dispData();
        bowl.calAvg();
        bowl.calPoints();
        }
        else if (get.nextInt() == 2) {
            Batsman bat = new Batsman();
        bat.readData();
        bat.dispData();
        bat.calAvg();
        bat.calPoints();
            }
       
}
    
}
