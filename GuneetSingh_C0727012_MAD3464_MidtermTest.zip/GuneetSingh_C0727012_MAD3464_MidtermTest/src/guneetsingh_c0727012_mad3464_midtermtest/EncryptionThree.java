/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guneetsingh_c0727012_mad3464_midtermtest;

/**
 *
 * @author macstudent
 */
public class EncryptionThree {
    
     char string[] = {'Z','A','N','I','L'};
     String reverse;
  
    
    void operatrion() {
        
        String str1 = new String(string);
       reverse = new StringBuffer(str1).reverse().toString();
       System.out.println("Reverse of string: " + reverse);
       char revString[] = reverse.toCharArray();
       
       for(int i=0;i<string.length;i++){
        
           System.out.println("ThreeENCNewString:" + string[i]+revString[i]);
       }
       
       
        }
    
}
