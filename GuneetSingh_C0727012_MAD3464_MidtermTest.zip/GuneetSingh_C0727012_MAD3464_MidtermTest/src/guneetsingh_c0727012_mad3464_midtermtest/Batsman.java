/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guneetsingh_c0727012_mad3464_midtermtest;

/**
 *
 * @author macstudent
 */
import java.util.*;
public class Batsman extends Player {
    
int noBowlsPlayed;
int runsTaken[] = new int[6];
int strikeRate;
int totalRuns;
int batingPoints = 0;

void readData() {
    super.readData();
    Scanner get = new Scanner(System.in);
    System.out.println("Enter the number of bowls played");
    noBowlsPlayed = get.nextInt();
    System.out.println("Enter the number of runs taken in 6 balls");
    for(int i = 0;i<runsTaken.length;i++) {
       runsTaken[i] = get.nextInt();
}
}

void dispData() {
    
    super.dispData();
    System.out.println("-----------Batsman---------");
    System.out.println("Number of bowls played " + noBowlsPlayed);
    System.out.println("Number of runs taken in 6 balls");
    for(int j=0;j<runsTaken.length;j++) {
        System.out.println(runsTaken[j]);
     }
}

void calAvg() {
    Scanner get = new Scanner(System.in);
    System.out.println("Enter total runs made by batsman");
    totalRuns = get.nextInt();
    strikeRate = totalRuns/noBowlsPlayed;
    System.out.println("Strike rate of batsman:" + strikeRate);
   }


void calPoints(){
    System.out.println("-----------Batsman Points---------");
    
    for(int i=0;i<runsTaken.length;i++) 
    {
        if (runsTaken[i] == 6) {
            batingPoints += 5;
        }
        else if (runsTaken[i] == 4) {
            batingPoints += 3;
        }
    }
    System.out.println("Total Points batsman made:" + batingPoints);
    
}
}
