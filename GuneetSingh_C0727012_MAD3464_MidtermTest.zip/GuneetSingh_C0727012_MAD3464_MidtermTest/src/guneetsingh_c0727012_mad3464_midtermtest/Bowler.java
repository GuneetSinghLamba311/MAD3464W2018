/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guneetsingh_c0727012_mad3464_midtermtest;

/**
 *
 * @author macstudent
 */
import java.util.*;
public class Bowler extends Player {

int noOversThrown;
int noRunsGiven;
int noWicketsTaken;
int runsPerOver;
int runsPerWicket;
int bowlingPoints=0;
int avgRunbowlingPoints=0;


 void readData() {
    
    super.readData();
    Scanner get = new Scanner(System.in);
    System.out.println("Enter the number of overs thrown");
    noOversThrown = get.nextInt();
    System.out.println("Enter the number of runsgiven");
    noRunsGiven = get.nextInt();
    System.out.println("Enter the number of wickets taken");
    noWicketsTaken = get.nextInt();
    
}
 
 void dispData() {
     
     super.dispData();
     System.out.println("-----------Bowler---------");
     System.out.println("number of overs thrown" + noOversThrown);
     System.out.println("number of runsgiven" + noRunsGiven);
     System.out.println("number of wickets taken" + noWicketsTaken);
     
 }
 
 void calAvg() {
     System.out.println("-----------Average---------");
     runsPerOver = noRunsGiven/noOversThrown;
     System.out.println("RunsPerOver are: " + runsPerOver);
     runsPerWicket = noRunsGiven/noWicketsTaken;
     System.out.println("RunsPerWicket are: " + runsPerWicket);
     }
 
 void calPoints() {
     System.out.println("-----------BowlerPoints---------");
     for(int i = 0;i<noWicketsTaken;i++) {
         bowlingPoints += 5;
        }
     System.out.println("Total Points based on wickets are:" + bowlingPoints);
     
if (runsPerOver > 1 && runsPerOver <= 3) {
    
    avgRunbowlingPoints = 10;
    
   }
else if (runsPerOver > 3) {
    avgRunbowlingPoints = 5;
}
 System.out.println("Total Points based on runPerOver:" + bowlingPoints);
     
 }
 
}
