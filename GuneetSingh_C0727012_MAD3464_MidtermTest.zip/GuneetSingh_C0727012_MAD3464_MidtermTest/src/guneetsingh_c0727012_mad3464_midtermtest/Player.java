/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guneetsingh_c0727012_mad3464_midtermtest;

/**
 *
 * @author macstudent
 */
import java.util.*;
public class Player {
    
    String playerID;
    String playerName;
    
    void readData() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter playerID:");
        playerID = input.nextLine();
        System.out.println("Enter playerName:");
        playerName = input.nextLine();
        }
   void dispData() {
        
       System.out.println("playerID:" + playerID);
        System.out.println("playerName:" + playerName);
       }
    
 }
