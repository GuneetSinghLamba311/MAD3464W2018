/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guneetsingh_c0727012_mad3464_midtermtest;

/**
 *
 * @author macstudent
 */
public class EncryptionTwo {
    

  char string[] = {'Z','A','N','I','L'};
    
    void operation() {
         
       for(int i=1;i<string.length;i++) {
         if(string[i] % 2==0) 
         {
             string[i] += 2;
         }
         
        
    }
        String s1 = new String(string);
         System.out.println("NewString = " + s1);
}
}
        
        
    
    
    
    

