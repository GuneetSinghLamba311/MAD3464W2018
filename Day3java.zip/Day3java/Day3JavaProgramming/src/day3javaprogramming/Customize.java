/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3javaprogramming;

/**
 *
 * @author macstudent
 */
class testException extends Exception { // Custom class to catch exception.
   
    public testException(String message) { // constructor that gives message when exception is called.
        super(message); // pass to super class exception. 
    }
}
public class Customize {
    
 public static void main(String args[]) throws Exception {
     
   int n1 = 10;
   
   try {
       
       if (n1==10) {
           throw new testException("Test unsuccessful");
       }
   }
       catch(testException e) {
               System.out.println("Customized exception");
               System.out.println(e.getMessage());
               System.out.println(e.getStackTrace()); // to know from where the exception has occured.
       } 
       
   }
     
     }   
    
 
