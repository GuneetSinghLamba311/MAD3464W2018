/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3javaprogramming;

/**
 *
 * @author macstudent
 */
public class Day3JavaProgramming {

    public static void main(String[] args) {
        int n1 = 10,n2=2;
        int ar1[] = {10,20,30};
        try {
            if (n2==0){
             throw new ArithmeticException();   
            }
            else {
            n1 = n1 / n2 ;
            }
            
            n2 = ar1[4];
            
        }
        
      
        catch(ArrayIndexOutOfBoundsException e) {      // Array out of bound exception.
            System.out.println("Array out of bound");
        }
        catch(ArithmeticException e)                // arihtmetic exception.
        {
            System.out.println("Unbale to divie by zero");
            
        }
          catch(Exception e) {
            System.out.println("Something is wrong.");
        }
        finally {
            System.out.println("Value of n1: " + n1);
            System.out.println("Value of n2: " + n2);
        }
 }
    
}
