/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3interfaces;

/**
 *
 * @author macstudent
 */
public class Day3Interfaces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        
        Addition op1 = new Addition();
        op1.display();
        A a1 = new A();
        a1.display();
        a1.calcMultiplication(); 
        B b1 = new B();
        b1.calcDivision();
        b1.calcMultiplication();
        b1.display();
        C c1 = new C();
        c1.display();
        
   }
}
    
  interface Arithmetic
  {
     int n1 = 10;
      int n2 = 10;
      void display();
  }
        
class Addition implements Arithmetic {
   // int n1 = 20;
    //int n2 = 30;
    @Override 
    public void display() {
        System.out.println("Inside addition");
        System.out.println(n1+n2);
        System.out.println("---------");
    }
}

class counting extends Addition {
    
}

interface multiplication extends Arithmetic
{
    void calcMultiplication();
   }

class A implements multiplication {
    @Override
    public void display() {
        System.out.println("Inside A");
         
        System.out.println(n1+n2);
         System.out.println("---------");
       
    }
    @Override
   public  void calcMultiplication()
    {
        System.out.println(n1*n2);
    }
 }

interface division extends Arithmetic {
    void calcDivision();
}

 class B extends Addition implements division, multiplication { // Hybrid inheritance.
    
    @Override 
    public void calcDivision() {
        System.out.println(n1/n2);
    }
        @Override
        public void calcMultiplication() {
         System.out.println(n1*n2);
    }
        
        @Override 
        public void display() {
            System.out.println("Inside B");
            System.out.println(n1+n2);
             System.out.println("---------");
        }
    }
class C extends B {
    
    
   @Override 
   public void display() {
        System.out.println("Inside C");
       System.out.println(n1+n2);
       System.out.println("---------");
   }
}

    
    
    

