
import java.util.Arrays;
import java.util.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Hello { // classes always start with upper case.

   // Execution always begin in main method
public static void main(String[] args) {
    
   int number = 10;  // variable name start from lowercase.
   float percentage;
   char vowel = 'a';
   String firstName = "Guneet";
   System.out.println("Value of number is :" + number);
   percentage = 7.8f;
   System.out.println("Value of percentage:" + percentage);
   System.out.println("Vowel = " + vowel);
   System.out.println("First Name:" + firstName);
 
   // Java uses ASCII Code that is why the following variables when changed showed
   // Different value.
   percentage = 10; 
   //number = 10.23;
   vowel = 35;
   number = 'J';
   System.out.println("Vowel: " + vowel);
   System.out.println("Number: " + number);
   System.out.println("Concatination: " + number + 12);// Concationation of two numbers;
   System.out.println(1+2 + "test");
   System.out.println("Add:" + (number+12));
   
   if (number > 10) {
       System.out.println("more than 10");
       
   }
   else if (number == 10) {
       System.out.println("equal to 10");
   }
   
   switch (number) {
       case 10:
           System.out.println("Value = 10");
           break;
       case 20:
           System.out.println("Value = 20");
           break;
       case 30:
           System.out.println("Value = 30");
           break;
           
       default:
           System.out.println(" NO matching Value");
           break;
           
   }
   
   vowel = 'a';
   switch(vowel) {
      // case ('a'|'i')
       
       case 'a':
       case 'i':
       case 'e':
       case 'o':
       case 'u':
           System.out.println("Vowel");
           break;
       default:
           System.out.println("Not a vowel");
       break;
       }
   
   String province = "Alberta";
   switch(province)
   {
       case "Ontario":
           System.out.println("ON");
           break;
        
       case "Alberta":
           System.out.println("AB");
           break;
       case "Prince Edward":
      System.out.println("PE");
      break;
       default:
           System.out.println("Unavailable");
           break;
      }
   
   
   int numbers[] = new int[5]; // Crating an array.
   int i;
   for(i=0;i<numbers.length;i++) {
       numbers[i] = (int)(Math.random() * 100); // Type Casting.
       
       System.out.println("numbers [" + i + "] = "+numbers[i]);
   }
  
   double PI_Value =  Math.PI;
   double power = Math.pow(2,2);
   Math.sqrt(144);
   Math.abs(PI_Value);
   float grades[][] = new float[3][4];

   for (i=0;i<3;i++) {
      for (int j=0;j<4;j++) {
          grades[i][j] = 10.0f;
          System.out.println("Grade is "+ grades[i][j]);
      }
   }
       
      float randomNumber;
      for (i=0;i<10;i++) {
          randomNumber = (float)(Math.random()*10);
          System.out.println("no" + (i+1 + "=" + randomNumber));
      }
      
      int randomNumberArray[] = new int[10];
      
      for(i=0;i<10;i++) {
          
       randomNumberArray[i] = (int)(Math.random()*10);
     System.out.println("Random Vlaue"+ randomNumberArray[i]);  
     }
      
      int anotherArray[] = new int[10];
      anotherArray = randomNumberArray;
      Arrays.sort(anotherArray); // for sorting the array.It sorts any type of array.
      for (i=0;i<10;i++)
      {
        
              System.out.println("Sorted Value:" + anotherArray[i]);
          }
      
      
     // Creating Square and Number Patterns with loops.
     
    String pattern;

    int noOfTimes;

    Scanner scanner = new Scanner(System.in);

    System.out.print("Enter the pattern to print : ");
    pattern = scanner.nextLine();

    System.out.print("Enter number of times it should get printed : ");
    noOfTimes = scanner.nextInt();

    for( i=1; i<=noOfTimes; i++) {      

        System.out.println();

        if(i==1 || i==noOfTimes) {

            for(int j=1; j<=noOfTimes; j++){

                System.out.print(pattern+" ");

            }
        }
        else {

            for(int k=1; k<=noOfTimes;k++) {

                if(k==1 || k == noOfTimes) {

                    System.out.print(pattern + " ");

                }                   
                else {

                    System.out.print("  ");

                }
            }

        }
    }




}
}
    

