-- phpMyAdmin SQL Dump
-- version 4.7.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 03, 2018 at 02:10 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `AirlineDatabase_MAD3464`
--

-- --------------------------------------------------------

--
-- Table structure for table `FlightDetails_Table`
--

CREATE TABLE `FlightDetails_Table` (
  `FlightNumber` int(20) NOT NULL,
  `FlightName` varchar(20) NOT NULL,
  `StartPoint` varchar(20) NOT NULL,
  `EndPoint` varchar(20) NOT NULL,
  `Date` varchar(20) NOT NULL,
  `Time` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Fare` int(20) NOT NULL,
  `Passengers` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `FlightDetails_Table`
--

INSERT INTO `FlightDetails_Table` (`FlightNumber`, `FlightName`, `StartPoint`, `EndPoint`, `Date`, `Time`, `Type`, `Fare`, `Passengers`) VALUES
(101, 'AIR-CANADA', 'DELHI', 'TORONTO', '21-DEC-2017', '10:30pm', 'REGULAR', 1200, 300),
(5, '5', '5', '5', '5', '5', '5', 5, 5),
(123, 'Lufthansa', 'delhi', 'toronto', '34', '12', 'RN', 450, 500),
(43, 'frf', 'frf', 'frrffr', 'r2342', '233', 'boing', 1200, 200);

-- --------------------------------------------------------

--
-- Table structure for table `Passengers_FlightDetails`
--

CREATE TABLE `Passengers_FlightDetails` (
  `Name` varchar(20) NOT NULL,
  `PhoneNumber` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Destination` varchar(20) NOT NULL,
  `SeatType` varchar(20) NOT NULL,
  `FlightName` varchar(20) NOT NULL,
  `FlightNumber` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Passengers_FlightDetails`
--

INSERT INTO `Passengers_FlightDetails` (`Name`, `PhoneNumber`, `Email`, `Destination`, `SeatType`, `FlightName`, `FlightNumber`) VALUES
('Guneet', '647', 'gdgergg', 'egegeg', 'ECONOMIC', 'egeg', '12'),
('tyutyu', '23', 'gfhfhh', 'fhf', 'ECONOMIC', 'hfh', '12'),
('yg', '32', 'rger', 'ew', 'BUSSINESS', 'rwerwr', '12'),
('ggr', '23', 'gdgdg', 'we', 'ECONOMIC', 'weet', '12'),
('ggr', '23', 'gdgdg', 'we', 'ECONOMIC', 'weet', '12'),
('gdfg', '12', 'fvdv', 'dfvdfv', 'BUSSINESS', 'er', '1'),
('yrty', 'hrrthh', 'rrthh', 'rth', 'ECONOMIC', 'htrh', 'hrtrth'),
('gdg', 'dg', 'dgdfgg', 'dfgd', 'ECONOMIC', 'gdg', 'dfgdfg'),
('egeg', 'egeg', 'geg', 'ge', 'BUSSINESS', 'eege', 'gege'),
('ghgfhh', 'dhdh', 'hddh', 'hdhd', 'ECONOMIC', 'hdhh', 'hdh'),
('trhrth', 'ghfgh', 'hfghf', 'fghfh', 'ECONOMIC', 'fhfh', '23'),
('gunrrt', '853963', 'gdfgdfnbfg', 'dbgb', 'BUSSINESS', 'ert', '12');

-- --------------------------------------------------------

--
-- Table structure for table `Registration`
--

CREATE TABLE `Registration` (
  `UserName` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Registration`
--

INSERT INTO `Registration` (`UserName`, `Password`) VALUES
('Guneet', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `Tickets`
--

CREATE TABLE `Tickets` (
  `TicketDescription` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Tickets`
--

INSERT INTO `Tickets` (`TicketDescription`) VALUES
('');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
